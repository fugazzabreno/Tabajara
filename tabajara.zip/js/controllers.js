angular.module('app.controllers', [])
  
.controller('homeCtrl', function($scope) {

})
   
.controller('produtoCtrl', function($scope) {

})
   
.controller('quemSomosCtrl', function($scope) {

})
      
.controller('contatoCtrl', function($scope) {

})
   
.controller('pGinaInicialCtrl', function($scope) {

})
   
.controller('signupCtrl', function($scope) {

})
 